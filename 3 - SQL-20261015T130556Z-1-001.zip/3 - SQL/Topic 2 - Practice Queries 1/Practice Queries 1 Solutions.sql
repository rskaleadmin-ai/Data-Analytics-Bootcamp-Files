-- Q1-  Display all records from a table
SELECT * FROM financial_transactions;
-- Q2 - Show only Transaction_ID and Amount Column
SELECT Transaction_ID, Amount FROM financial_transactions;
-- Q3 - Display Customer_ID and Payment_Method
SELECT Customer_ID, Payment_Method FROM financial_transactions;
-- Q4 - Show unique Payment_Method values
SELECT DISTINCT(Payment_Method) FROM financial_transactions;
-- Q5 - Display Unique STATUS values
SELECT DISTINCT(Status) FROM financial_transactions;
-- Q6 - Show first 10 records from the table
SELECT * FROM financial_transactions LIMIT 10;
-- Q7 - Display Transaction_ID and Amount columns. Display Amount column as "TXN_amount"
SELECT Transaction_ID, Amount AS Txn_amount FROM financial_transactions;
-- Q8 - Show All transactions sorted by AMOUNT(highest first)
SELECT * FROM financial_transactions 
ORDER BY Amount DESC;
-- Q9 - Display all records sorted by Customer_ID (ASCENDING)
SELECT * FROM financial_transactions
ORDER BY Customer_ID ASC;
-- Q10- Show Transaction_ID and Status sorted by Status
SELECT Transaction_ID, Status FROM financial_transactions
ORDER BY Status;
-- Q11 - Find all transactions where Amount > 8000
SELECT * FROM financial_transactions
WHERE Amount > 8000;
-- Q12 - Show transactions where Amount < 2000
SELECT * FROM financial_transactions
WHERE Amount < 2000;
-- Q13 - Get all transaction where Payment_Method = 'Completed'
SELECT * FROM financial_transactions
WHERE Payment_Method = 'Completed';
-- Q14- Find transactions where Status is 'Pending'
SELECT * FROM financial_transactions
WHERE Status = 'Pending';
-- Q15- Find transcation where Amount is between 3000 and 7000
SELECT * FROM financial_transactions
WHERE Amount BETWEEN 3000 AND 7000;
-- Q16 - Get transaction where Amount is not equal to 5000
SELECT * FROM financial_transactions
WHERE Amount != 5000;
-- Q17 - Show transactions where Payment_method is not 'Delivered'
SELECT * FROM financial_transactions
WHERE Payment_Method != 'Delivered';
-- Q18 - Find transactions where Payment_method is either 'A' or 'B'
SELECT * FROM financial_transactions
WHERE Payment_Method = 'A' OR Payment_Method = 'B';
-- Q19 - Display transaction where Status starts with 'C'
SELECT * FROM financial_transactions
WHERE Status LIKE 'C%';
-- Q20 - Show transcations where Payment_method ends with 'd'
SELECT * FROM financial_transactions
WHERE Payment_Method LIKE '%d';
-- Q21 - Find transactions where Amount > 8000 and Status = 'Completed'
SELECT * FROM financial_transactions
WHERE Amount > 8000 AND Status = 'Completed';
-- Q22 - Show transactions where Amount < 3000 and Payment_Method = 'B'
SELECT * FROM financial_transactions
WHERE Amount < 3000 AND Payment_Method = 'B';
-- Q23 - Get transactions where Payment_Method = 'A' or 'B'
SELECT * FROM financial_transactions
WHERE Payment_Method = 'A' OR Payment_Method = 'B';
-- Q24 - Show transactions where Status = 'Pending' OR Amount > 9000
SELECT * FROM financial_transactions
WHERE Status = 'Pending' OR Amount > 9000;
-- Q25 - Find transactions where Amount > 7000 and Payment_method = 'Completed'
SELECT * FROM financial_transactions
WHERE Amount > 7000 AND Payment_Method = 'Completed';
-- Q26 - Show transactions where Staus is not 'Completed'
SELECT * FROM financial_transactions
WHERE Status != 'Completed';
-- Q27 - Get transactions where NOT Payment_Method = 'Pending'
SELECT * FROM financial_transactions
WHERE NOT Payment_Method = 'Pending';
-- Q28 - Find transactions where Amount between 4000 and 9000 and Status = 'Delivered'
SELECT * FROM financial_transactions
WHERE (Amount BETWEEN 4000 AND 9000) AND (Status = 'Delivered');
-- Q29 - Show transaction where Payment_method starts with 'C' and Amount > 5000
SELECT * FROM financial_transactions
WHERE Payment_Method LIKE 'C%' AND Amount > 5000;
-- Q30 - Get transactions where (Amount > 8000 OR Status = 'Pending') AND Payment_Method = 'Delivered'
SELECT * FROM financial_transactions
WHERE ( Amount > 8000 OR Status = 'Pending') AND Payment_Method = 'Delivered';
