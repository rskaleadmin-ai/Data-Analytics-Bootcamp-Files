-- 🔹 Level 1: CREATE TABLE

-- Q1
CREATE TABLE employees (
  id INT,
  name VARCHAR(50),
  salary INT
);

-- Q2
CREATE TABLE products (
  Product_ID INT,
  Product_Name VARCHAR(50),
  Price INT
);

-- Q3
CREATE TABLE orders (
  Order_ID INT,
  Customer_ID INT,
  Amount INT
);

-- Q4
CREATE TABLE users (
  user_id INT,
  is_active BOOLEAN
);

-- Q5
CREATE TABLE students (
  id INT,
  name VARCHAR(50),
  department VARCHAR(50)
);


-- 🔹 Level 2: ALTER TABLE

-- Q6
ALTER TABLE employees
ADD email VARCHAR(100);

-- Q7
ALTER TABLE students
ADD age INT;

-- Q8
ALTER TABLE employees
MODIFY salary BIGINT;

-- Q9
ALTER TABLE employees
RENAME COLUMN name TO employee_name;

-- Q10
ALTER TABLE students
DROP COLUMN age;

-- Q11
ALTER TABLE products
ADD stock INT,
ADD category VARCHAR(50);

-- Q12
ALTER TABLE products
MODIFY Product_Name VARCHAR(100);


-- 🔹 Level 3: DROP TABLE

-- Q13
DROP TABLE students;

-- Q14
DROP TABLE orders;

-- Q15
DROP TABLE IF EXISTS customers;

-- Q16
DROP TABLE IF EXISTS employees, products;


-- 🔹 Level 4: Practical Understanding

-- Q17
CREATE TABLE test1 (
  id INT
);

ALTER TABLE test1
ADD name VARCHAR(50);

-- Q18
CREATE TABLE test2 (
  id INT,
  amount INT
);

ALTER TABLE test2
MODIFY amount BIGINT;

-- Q19
CREATE TABLE test3 (
  id INT,
  temp_col INT
);

ALTER TABLE test3
DROP COLUMN temp_col;

-- Q20
CREATE TABLE test4 (
  id INT
);

DROP TABLE test4;