SELECT * FROM financial_transactions;

-- 1 - Show all transactions and create a column Amount_Level: Amount > 7000 → 'High' else → 'Low';
SELECT *,
	(CASE
		WHEN Amount > 7000 THEN 'HIGH' ELSE 'LOW'
    END) AS amount_level
FROM financial_transactions;

-- Display Transaction_ID and create Status_Label: - 'Completed' → 'Done' - others → 'Pending'
SELECT Transaction_ID, 
	(CASE
		WHEN Status = 'Completed' Then 'Done' ELSE 'Pending'
	END) AS Status_lable
FROM financial_transactions;

-- 3. Create Amount_Category: - >8000 → 'High' , - 4000–8000 → 'Medium', - else → 'Low'
SELECT *, 
	(CASE
		WHEN Amount > 8000 THEN 'HIGH'
        WHEN Amount BETWEEN 4000 AND 8000 THEN 'MEDIUM'
        ELSE 'LOW'
	END) as AMOUNT_category
FROM financial_transactions;

-- 4 - Show Payment_Method and label:- 'A','B' → 'Card', - others → 'Other'
SELECT Payment_Method, 
	(CASE
		WHEN Payment_Method IN ('A', 'B') THEN 'CARD'
        ELSE 'Other'
	END) as Payment_Label
FROM financial_transactions;

-- 5 - Create Valid_Status: - 'Completed' → 'Valid', - else → 'Check'
SELECT *,
	(CASE
		WHEN Status = 'Completed' THEN 'Valid'
        ELSE 'Check'
	END) AS Valid_Status
FROM financial_transactions;

-- 6 - Create Priority: - Status = 'Completed' AND Amount > 7000 → 'High Priority', - else → 'Normal'
SELECT *, 
	(CASE
		WHEN (Status = 'Completed' AND Amount > 7000) THEN 'HIGH PRIORITY'
        ELSE 'NORMAL'
	END) AS Priority
FROM financial_transactions;

-- 7-Clean the Status column: - Replace 'C' with 'Completed' , ELSE STATUS
SELECT *,
	(CASE
		WHEN Status = 'C' THEN 'Completed'
        ELSE STATUS
	END) AS STATUS_EDITED
FROM financial_transactions;

-- 8 - Standardize Payment_Method: - 'A','B' → 'Card', - 'Delivered','Pending' → 'Cash', - others → 'Other'
SELECT *,
	(CASE
		WHEN Payment_Method IN ('A', 'B') THEN 'CARD'
        WHEN Payment_Method IN ('Delivered', 'Pending') THEN 'CASH'
        ELSE 'OTHER'
	END) AS PAYMENT_CATEGORY
FROM financial_transactions;
-- 9 - Create Transaction_Tag:- Amount > 8000 AND Status = 'Completed' → 'Top', - else → 'Regular'
SELECT *,
	(CASE
		WHEN (Amount > 8000 AND Status = 'Completed') THEN 'TOP'
        ELSE 'REGULAR'
	END) AS Transaction_tag
FROM financial_transactions;
-- 10 - Create Value_Label: - Amount < 2000 → 'Low Value', - else → 'Normal'
SELECT *,
	(CASE
		WHEN Amount < 2000 THEN 'LOW VALUE'
        ELSE 'NORMAL'
	END) AS Value_lable
FROM financial_transactions;
-- 11 - Count number of transactions based on Category Slab: - (Amount > 7000) - 'High', ELSE 'Low'
SELECT 
	(CASE
		WHEN Amount > 7000 THEN 'HIGH'
        ELSE 'LOW'
	END) AS Category, 
    COUNT(*) AS Total_Count
FROM financial_transactions
GROUP BY Category;
-- Find total transaction amount based on Category Slab - 'High' > 700  Else 'Low'
SELECT
	(CASE
		WHEN Amount > 7000 THEN 'HIGH'
        ELSE 'LOW'
	END) AS Category,
    SUM(Amount) as Total_amt
FROM financial_transactions
GROUP BY Category;
-- .13 Show total revenue by cleaned Status- when Status = 'C' Then 'Completed',Else STATUS
 SELECT
	(CASE
		WHEN Status = 'C' THEN 'Completed'
        ELSE Status
	END) as Category,
    SUM(Amount) As Total_amt
FROM financial_transactions
GROUP BY Category;
-- 14 Find average Amount per category: Amount > 8000 then High, Between 4000 to 8000 Medium Else Low
SELECT
	(CASE
		WHEN Amount > 8000 THEN 'HIGH'
        WHEN Amount BETWEEN 4000 AND 8000 THEN 'MEDIUM'
        ELSE 'LOW'
	END) AS Category,
    AVG(Amount) as avg_amt
FROM financial_transactions
GROUP BY Category;
-- Count transactions per Payment_Method category: When Payment_Method = 'A' or 'B' Then- 'Card', ELSE  'Other'
SELECT
	(CASE
		WHEN Payment_Method IN ('A', 'B') THEN 'CARD'
        ELSE 'OTHER'
	END) AS Category,
    COUNT(*) AS Transaction_count
FROM financial_transactions
GROUP BY Category;
-- .16 Create Risk_Level: - Amount > 9000 → 'High Risk', - 5000–9000 → 'Medium Risk', - else → 'Low Risk'
SELECT *,
	(CASE
		WHEN Amount > 9000 THEN 'high risk'
        WHEN Amount BETWEEN 5000 AND 9000 THEN 'medium risk'
        ELSE 'low risk'
	END) AS Risk_level
FROM financial_transactions;
-- 17 Label transactions:- Amount > 8000 → 'Premium' , - else → 'Regular'
SELECT *,
	(CASE
		WHEN Amount > 8000 THEN 'Premium'
        ELSE 'Regular'
	END) AS category
FROM financial_transactions;
-- Find total revenue by Risk_Level - WHEN AMOUNT > 9000 THEN 'HIGH', 5000 TO 9000 THEN 'MEDIUM', ELSE 'LOW'


    















